export const DB = {
      theories: {
        "TH_OSI7": {
          id: "TH_OSI7", category: "S1_NET", categoryName: "1과목: 네트워크 일반",
          title: "OSI 7계층 구조와 계층별 전송 단위(PDU)",
          summary: "1계층 물리(Bit) → 2계층 데이터링크(Frame, MAC 주소) → 3계층 네트워크(Packet, IP 주소/라우팅) → 4계층 전송(Segment, Port/TCP·UDP).",
          points: ["2계층(데이터링크): 브리지, 스위치 / MAC 주소 기반 Frame 전송 및 오류 제어", "3계층(네트워크): 라우터 / IP 주소 기반 최적 경로 라우팅", "4계층(전송): TCP(연결지향·신뢰성) vs UDP(비연결성·실시간 고속 전송)"],
          quiz: { q: "[이론 확인] OSI 7계층 중 MAC 주소를 사용하며 데이터 전송 단위가 'Frame(프레임)'인 계층은?", opts: ["1계층 물리 계층", "2계층 데이터링크 계층", "3계층 네트워크 계층"], ans: 1, exp: "데이터링크 계층(2계층)은 Frame 단위로 전송하며 MAC 주소를 사용합니다." }
        },
        "TH_CSMA": {
          id: "TH_CSMA", category: "S1_NET", categoryName: "1과목: 네트워크 일반",
          title: "매체 접근 제어: CSMA/CD vs CSMA/CA",
          summary: "유선 이더넷(IEEE 802.3)은 충돌을 감지하는 CSMA/CD를 사용하고, 무선 LAN(IEEE 802.11)은 충돌을 사전에 회피하는 CSMA/CA를 사용합니다.",
          points: ["CSMA/CD: 충돌 발생 시 Jam 신호 송출 후 랜덤 시간 대기(Back-off) 후 재전송", "CSMA/CA: 무선 환경에서 RTS/CTS 프레임으로 충돌 사전 회피"],
          quiz: { q: "[이론 확인] 무선 LAN(IEEE 802.11)에서 데이터 충돌을 사전에 회피하기 위해 사용하는 방식은?", opts: ["CSMA/CD", "CSMA/CA", "Token Ring"], ans: 1, exp: "무선 LAN은 충돌 회피 방식인 CSMA/CA를 사용합니다." }
        },
        "TH_SUBNET": {
          id: "TH_SUBNET", category: "S2_TCPIP", categoryName: "2과목: TCP/IP",
          title: "IPv4 서브넷팅 & CIDR 가용 호스트 계산 공식",
          summary: "C클래스(/24) 기준 마지막 옥텟(8비트)에서 1의 개수가 서브넷 비트(n), 0의 개수가 호스트 비트(h)입니다.",
          points: ["분할 서브넷 수 = 2^n 개 / 서브넷당 가용 호스트 수 = (2^h - 2) 개", "/25(.128, 호스트 126개), /26(.192, 62개), /27(.224, 30개), /28(.240, 14개)"],
          quiz: { q: "[이론 확인] /26 (255.255.255.192) 서브넷 마스크에서 서브넷당 가용 호스트 수는?", opts: ["30개", "62개", "126개"], ans: 1, exp: "/26은 호스트 비트가 6개이므로 2^6 - 2 = 62개입니다." }
        },
        "TH_ARP": {
          id: "TH_ARP", category: "S2_TCPIP", categoryName: "2과목: TCP/IP",
          title: "ARP / RARP 프로토콜 및 필수 포트 번호",
          summary: "논리적 IP 주소를 물리적 MAC 주소로 변환하는 프로토콜은 ARP이며, 반대는 RARP입니다.",
          points: ["ARP: IP → MAC 변환 / RARP: MAC → IP 변환 / ICMP: 오류 보고 및 ping 테스트", "필수 포트: FTP(20,21), SSH(22), Telnet(23), SMTP(25), DNS(53), HTTP(80), HTTPS(443)"],
          quiz: { q: "[이론 확인] 논리적 IP 주소를 물리적 MAC 주소로 변환하는 프로토콜은?", opts: ["ARP", "RARP", "ICMP"], ans: 0, exp: "ARP(Address Resolution Protocol)가 IP를 MAC 주소로 변환합니다." }
        },
        "TH_LINUX": {
          id: "TH_LINUX", category: "S3_NOS", categoryName: "3과목: NOS",
          title: "Linux 권한 설정(chmod) 및 핵심 네트워크 설정 파일",
          summary: "소유자(User)·그룹(Group)·기타(Other)에 대해 읽기(r=4), 쓰기(w=2), 실행(x=1) 권한을 합산하여 부여합니다.",
          points: ["chmod 750: 소유자 rwx(7), 그룹 r-x(5), 기타 ---(0)", "/etc/resolv.conf: DNS 네임서버 IP 지정 / /etc/hosts: 호스트명-IP 매핑"],
          quiz: { q: "[이론 확인] Linux에서 DNS 서버 IP 주소(nameserver)를 설정하는 파일 경로는?", opts: ["/etc/fstab", "/etc/resolv.conf", "/etc/passwd"], ans: 1, exp: "/etc/resolv.conf 파일에 nameserver 주소를 등록합니다." }
        },
        "TH_DEVICE": {
          id: "TH_DEVICE", category: "S4_HW", categoryName: "4과목: 네트워크 운용기기",
          title: "네트워크 운용기기 (라우터 · 스위치 · VLAN)",
          summary: "스위치(2계층)는 충돌 도메인을 나누고, 라우터(3계층)와 VLAN은 브로드캐스트 도메인을 분할합니다.",
          points: ["라우터(3계층): 서로 다른 네트워크 연결 및 최적 경로 설정", "VLAN: 물리적 위치와 무관하게 스위치 포트를 논리적으로 묶어 브로드캐스트 도메인 분할"],
          quiz: { q: "[이론 확인] 스위치 포트를 논리적으로 그룹화하여 브로드캐스트 도메인을 분할하는 기술은?", opts: ["VLAN", "NAT", "VPN"], ans: 0, exp: "VLAN(가상 랜)은 논리적으로 브로드캐스트 도메인을 분리합니다." }
        },
        "TH_CABLE": {
          id: "TH_CABLE", category: "P_PRACTICAL", categoryName: "실기 핵심이론",
          title: "[실기 작업형] UTP 케이블 T568A/B 배열 및 Windows Server",
          summary: "실기 1번 필수 문제인 다이렉트(T568B-T568B) 및 크로스(T568B-T568A) 케이블 선 배열 공식입니다.",
          points: ["T568B 표준: 1.주띠 - 2.주 - 3.녹띠 - 4.파 - 5.파띠 - 6.녹 - 7.갈띠 - 8.갈", "다이렉트(이종 장비: PC-스위치) / 크로스(동종 장비: PC-PC, 라우터-라우터)"],
          quiz: { q: "[이론 확인] T568B 표준 배열에서 1번~3번 핀의 색상 순서로 올바른 것은?", opts: ["주띠 - 주 - 녹띠", "녹띠 - 녹 - 주띠", "주띠 - 녹띠 - 파"], ans: 0, exp: "T568B는 주띠-주-녹띠-파-파띠-녹-갈띠-갈 순서입니다." }
        },
        "TH_ROUTER": {
          id: "TH_ROUTER", category: "P_PRACTICAL", categoryName: "실기 핵심이론",
          title: "[실기 에뮬레이터] Cisco Router IOS 필수 명령어",
          summary: "인터페이스 설정 후 활성화(no shutdown)와 관리자 모드에서 설정 저장(copy r s)이 핵심입니다.",
          points: ["enable → configure terminal (conf t) → interface fastethernet 0/0", "ip address [IP] [Mask] → no shutdown (no sh)", "저장: copy running-config startup-config (축약: copy r s)"],
          quiz: { q: "[이론 확인] 라우터 현재 실행 설정(RAM)을 NVRAM에 영구 저장하는 명령어는?", opts: ["copy startup-config running-config", "copy running-config startup-config", "show running-config"], ans: 1, exp: "copy running-config startup-config (copy r s) 명령어로 저장합니다." }
        }
      },

      written: [
        { id: "WQ_01", sub: "S1_NET", subName: "1과목: 네트워크 일반", theoryId: "TH_OSI7", q: "OSI 7계층 중 프레임(Frame) 단위의 데이터 전송 및 MAC 주소를 이용한 물리적 주소 지정을 담당하는 계층은?", code: null, choices: ["물리 계층", "데이터링크 계층", "네트워크 계층", "전송 계층"], ans: 1, exp: "2계층 데이터링크 계층은 Frame 단위 전송과 MAC 주소 지정을 담당합니다." },
        { id: "WQ_02", sub: "S1_NET", subName: "1과목: 네트워크 일반", theoryId: "TH_CSMA", q: "유선 이더넷(IEEE 802.3) 환경에서 충돌 감지 시 Jam 신호를 송출하고 임의의 시간 대기 후 재전송하는 매체 접근 제어 방식은?", code: null, choices: ["CSMA/CA", "CSMA/CD", "Token Ring", "FDDI"], ans: 1, exp: "유선 이더넷은 충돌 탐지 방식인 CSMA/CD를 사용합니다." },
        { id: "WQ_03", sub: "S2_TCPIP", subName: "2과목: TCP/IP", theoryId: "TH_SUBNET", q: "C클래스 네트워크(192.168.100.0)를 255.255.255.192(/26) 서브넷 마스크로 분할했을 때 서브넷당 사용 가능한 호스트 수는?", code: "Subnet Mask: 255.255.255.192 (/26)", choices: ["14개", "30개", "62개", "126개"], ans: 2, exp: "192는 11000000이므로 호스트 비트(0)가 6개입니다. 2^6 - 2 = 62개입니다." },
        { id: "WQ_04", sub: "S2_TCPIP", subName: "2과목: TCP/IP", theoryId: "TH_ARP", q: "TCP/IP 네트워크에서 논리적인 IP 주소를 물리적인 하드웨어 주소(MAC Address)로 변환해 주는 프로토콜은?", code: null, choices: ["RARP", "ICMP", "ARP", "IGMP"], ans: 2, exp: "ARP는 IP 주소를 MAC 주소로 변환하는 프로토콜입니다." },
        { id: "WQ_05", sub: "S3_NOS", subName: "3과목: NOS", theoryId: "TH_LINUX", q: "Linux 시스템에서 'app.sh' 파일의 권한을 소유자는 rwx, 그룹은 r-x, 기타 사용자는 권한 없음으로 설정하는 명령어는?", code: "$ chmod [권한번호] app.sh", choices: ["chmod 750 app.sh", "chmod 755 app.sh", "chmod 640 app.sh", "chmod 700 app.sh"], ans: 0, exp: "소유자 7(4+2+1), 그룹 5(4+1), 기타 0이므로 chmod 750입니다." },
        { id: "WQ_06", sub: "S3_NOS", subName: "3과목: NOS", theoryId: "TH_LINUX", q: "Linux 시스템에서 도메인 이름을 IP 주소로 변환하기 위해 질의할 DNS 네임서버 주소를 등록하는 설정 파일은?", code: "nameserver 168.126.63.1", choices: ["/etc/hosts", "/etc/resolv.conf", "/etc/fstab", "/etc/passwd"], ans: 1, exp: "/etc/resolv.conf 파일에 nameserver 지시자로 DNS 서버 IP를 설정합니다." },
        { id: "WQ_07", sub: "S4_HW", subName: "4과목: 네트워크 운용기기", theoryId: "TH_DEVICE", q: "OSI 3계층 장비로 브로드캐스트 도메인을 분할하며 서로 다른 네트워크 간 최적의 경로를 설정해 패킷을 전달하는 장비는?", code: null, choices: ["리피터", "더미 허브", "브리지", "라우터"], ans: 3, exp: "라우터(Router)는 3계층 장비로 브로드캐스트 도메인을 분할하고 라우팅을 수행합니다." },
        { id: "WQ_08", sub: "S4_HW", subName: "4과목: 네트워크 운용기기", theoryId: "TH_DEVICE", q: "물리적 위치와 상관없이 스위치 포트를 논리적으로 그룹화하여 브로드캐스트 도메인을 분할하는 기술은?", code: null, choices: ["VLAN", "NAT", "VPN", "STP"], ans: 0, exp: "VLAN(가상 랜)은 스위치 내부에서 논리적으로 브로드캐스트 도메인을 분리합니다." }
      ],

      practical: [
        { id: "PQ_01", pType: "CLI_ROUTER", pTypeName: "실기: Router CLI", theoryId: "TH_ROUTER", q: "[라우터 실습 1] FastEthernet 0/0 인터페이스 설정 모드에서 포트를 활성화(켜기)하는 명령어를 입력하세요.", scenario: "현재 프롬프트: Router(config-if)#\nIP 주소 설정 후 인터페이스를 Up 상태로 활성화해야 합니다.", prompt: "Router(config-if)#", cmds: ["no shutdown", "no shut", "no sh"], hint: "shutdown의 반대 명령어 (no ...)", exp: "'no shutdown'(축약: no sh)을 입력해야 인터페이스가 활성화됩니다." },
        { id: "PQ_02", pType: "CLI_ROUTER", pTypeName: "실기: Router CLI", theoryId: "TH_ROUTER", q: "[라우터 실습 2] 관리자 모드(Router#)에서 현재 실행 설정(RAM)을 NVRAM에 영구 저장하는 명령어를 입력하세요.", scenario: "현재 프롬프트: Router#\n모든 라우터 설정 완료 후 반드시 저장해야 채점됩니다.", prompt: "Router#", cmds: ["copy running-config startup-config", "copy run start", "copy r s", "write memory", "wr"], hint: "copy [현재설정] [시작설정] 또는 축약어 copy r s", exp: "'copy running-config startup-config'(축약: copy r s)로 NVRAM에 저장합니다." },
        { id: "PQ_03", pType: "CLI_LINUX", pTypeName: "실기: Linux 명령어", theoryId: "TH_LINUX", q: "[Linux 단답형] 현재 시스템의 모든 네트워크 연결 상태(-a)와 포트 번호를 숫자(-n)로 출력하는 netstat 명령어를 입력하세요.", scenario: "관리자가 리눅스 서버에서 열린 포트와 연결 상태를 숫자로 확인하려 합니다.", prompt: "[root@icqa ~]#", cmds: ["netstat -an", "netstat -na", "ss -an"], hint: "netstat 명령어에 -a 와 -n 옵션 결합", exp: "'netstat -an'은 모든 소켓(-a)을 숫자 주소(-n)로 출력합니다." },
        { id: "PQ_04", pType: "WORK_SIM", pTypeName: "실기: 케이블링 & 서버", theoryId: "TH_CABLE", q: "[케이블 제작 실기] PC와 스위치를 연결하는 다이렉트 케이블(T568B 표준)의 1번~8번 핀 색상 배열을 선택하세요.", scenario: "이종 장비 연결 시 양쪽 모두 T568B 표준으로 배열합니다.", choices: ["1.주띠 - 2.주 - 3.녹띠 - 4.파 - 5.파띠 - 6.녹 - 7.갈띠 - 8.갈", "1.주띠 - 2.주 - 3.녹띠 - 4.녹 - 5.파띠 - 6.파 - 7.갈띠 - 8.갈", "1.녹띠 - 2.녹 - 3.주띠 - 4.파 - 5.파띠 - 6.주 - 7.갈띠 - 8.갈", "1.주띠 - 2.주 - 3.파띠 - 4.파 - 5.녹띠 - 6.녹 - 7.갈띠 - 8.갈"], ans: 0, exp: "T568B 표준은 [주띠-주-녹띠-파-파띠-녹-갈띠-갈] 순서입니다." },
        { id: "PQ_05", pType: "WORK_SIM", pTypeName: "실기: 케이블링 & 서버", theoryId: "TH_ARP", q: "[Windows Server 실기] DNS 서버에서 IP 주소를 도메인 이름으로 역변환하기 위해 생성하는 조회 영역과 레코드는?", scenario: "정방향(도메인→IP)과 반대인 IP→도메인 변환 설정입니다.", choices: ["역방향 조회 영역 - PTR(포인터) 레코드", "정방향 조회 영역 - CNAME 레코드", "역방향 조회 영역 - MX 레코드", "정방향 조회 영역 - A 레코드"], ans: 0, exp: "IP를 도메인으로 역변환할 때는 역방향 조회 영역에 PTR 레코드를 생성합니다." }
      ]
    };
