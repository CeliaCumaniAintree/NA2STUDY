import { DB } from './data/db.js';

class AppController {
      constructor() {
        this.STORAGE_KEY = "NA2_STUDY_MASTER_V2";
        this.state = this.loadState();
        this.tFilter = "ALL";
        this.wSub = "ALL";
        this.wIdx = 0;
        this.pSub = "ALL";
        this.pIdx = 0;
        this.wMode = "ACTIVE";
        this.timerSec = 1200;
        this.bits = [true, true, false, false, false, false, false, false]; // 초기 192 (128+64)
      }

      defaultState() {
        return { theories: {}, questions: {}, logs: [] };
      }

      loadState() {
        try {
          const raw = localStorage.getItem(this.STORAGE_KEY);
          return raw ? { ...this.defaultState(), ...JSON.parse(raw) } : this.defaultState();
        } catch (_) { return this.defaultState(); }
      }

      saveState() {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.state));
      }

      getQStat(id) {
        if (!this.state.questions[id]) {
          this.state.questions[id] = { solved: 0, correct: 0, wrong: 0, streak: 0, bookmarked: false, mastered: false, lastOk: null };
        }
        return this.state.questions[id];
      }

      recordAttempt(id, isOk, label, title) {
        const st = this.getQStat(id);
        st.solved += 1;
        st.lastOk = isOk;
        let grad = false;
        if (isOk) {
          st.correct += 1;
          st.streak += 1;
          if ((st.wrong > 0 || st.bookmarked) && st.streak >= 2 && !st.mastered) {
            st.mastered = true;
            st.bookmarked = false;
            grad = true;
          }
        } else {
          st.wrong += 1;
          st.streak = 0;
          st.mastered = false;
        }
        this.state.logs.unshift({
          time: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
          label, id, title: title.slice(0, 38) + "...", isOk, grad
        });
        this.state.logs = this.state.logs.slice(0, 50);
        this.saveState();
        return { st, grad };
      }

      recordTheoryQuiz(thId, isOk, title) {
        this.state.theories[thId] = { solved: true, isOk };
        this.state.logs.unshift({
          time: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
          label: "이론퀴즈", id: thId, title, isOk, grad: false
        });
        this.saveState();
      }

      init() {
        this.bindEvents();
        this.startTimer();
        this.runSubnetCalculator();
        this.renderBits();
        this.refreshAll();
      }

      startTimer() {
        setInterval(() => {
          this.timerSec -= 1;
          const abs = Math.abs(this.timerSec);
          const m = String(Math.floor(abs / 60)).padStart(2, "0");
          const s = String(abs % 60).padStart(2, "0");
          document.getElementById("topTimer").textContent = `${this.timerSec < 0 ? "+" : ""}${m}:${s}`;
        }, 1000);
      }

      switchTab(tab) {
        ["dashboard", "theory", "written", "practical", "wrongnote", "records"].forEach(t => {
          document.getElementById(`view-${t}`).classList.toggle("hidden", t !== tab);
        });
        document.querySelectorAll(".main-tab-btn").forEach(btn => {
          const active = btn.getAttribute("data-tab") === tab;
          btn.className = active
            ? "main-tab-btn px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-indigo-600 text-white transition flex items-center gap-1.5"
            : "main-tab-btn px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-slate-300 hover:bg-slate-800 transition flex items-center gap-1.5";
        });
        this.refreshAll();
      }

      // 실시간 IP 서브넷 계산기 (예: 192.168.100.128 / 26)
      runSubnetCalculator() {
        const ipStr = document.getElementById("subnetIpInput").value.trim();
        const cidr = Math.min(30, Math.max(24, Number(document.getElementById("subnetCidrInput").value) || 26));
        const parts = ipStr.split(".").map(Number);
        const box = document.getElementById("subnetResultBox");

        if (parts.length !== 4 || parts.some(n => isNaN(n) || n < 0 || n > 255)) {
          box.innerHTML = `<p class="text-rose-400">올바른 IPv4 주소를 입력하세요. (예: 192.168.100.128)</p>`;
          return;
        }

        const hostBits = 32 - cidr;
        const blockSize = Math.pow(2, hostBits);
        const maskOctet = 256 - blockSize;
        const subnetCount = Math.pow(2, cidr - 24);
        const usableHosts = Math.max(0, blockSize - 2);

        const netStart = Math.floor(parts[3] / blockSize) * blockSize;
        const broadcast = netStart + blockSize - 1;
        const prefix3 = `${parts[0]}.${parts[1]}.${parts[2]}`;

        box.innerHTML = `
          <div class="flex justify-between border-b border-slate-800 pb-1.5">
            <span class="text-slate-400">입력 IP / 프리픽스:</span>
            <strong class="text-indigo-300">${ipStr} / ${cidr}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">서브넷 마스크:</span>
            <strong class="text-cyan-300">255.255.255.${maskOctet}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">네트워크 ID:</span>
            <strong class="text-emerald-400">${prefix3}.${netStart}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">브로드캐스트 주소:</span>
            <strong class="text-amber-300">${prefix3}.${broadcast}</strong>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">가용 호스트 범위:</span>
            <strong class="text-white">${prefix3}.${netStart + 1} ~ .${broadcast - 1}</strong>
          </div>
          <div class="flex justify-between pt-1 border-t border-slate-800">
            <span class="text-slate-400">서브넷 수 / 가용 호스트:</span>
            <strong class="text-emerald-300">${subnetCount}개 서브넷 / ${usableHosts}개 호스트</strong>
          </div>
        `;
      }

      renderBits() {
        const vals = [128, 64, 32, 16, 8, 4, 2, 1];
        const row = document.getElementById("bitToggleRow");
        row.innerHTML = "";
        vals.forEach((v, i) => {
          const on = this.bits[i];
          const btn = document.createElement("button");
          btn.className = `py-1.5 rounded-lg font-mono text-xs font-bold border ${on ? "bg-indigo-600 text-white border-indigo-400" : "bg-slate-950 text-slate-500 border-slate-800"}`;
          btn.innerHTML = `<div>${v}</div><div class="text-[10px]">${on ? "1" : "0"}</div>`;
          btn.onclick = () => { this.bits[i] = !this.bits[i]; this.renderBits(); };
          row.appendChild(btn);
        });
        const sum = vals.reduce((acc, v, i) => acc + (this.bits[i] ? v : 0), 0);
        document.getElementById("bitSumVal").textContent = sum;
      }

      // 연계 이론 + 미니 퀴즈 HTML 생성기
      buildLinkedTheoryHtml(theoryId, isOk, exp, grad, uid) {
        const th = DB.theories[theoryId];
        const banner = isOk
          ? `<div class="p-4 rounded-xl bg-emerald-950/70 border border-emerald-500/70 text-xs space-y-1">
               <div class="font-bold text-sm text-emerald-300">🟢 정답입니다! ${grad ? "🎉 (2회 연속 정답으로 오답노트에서 졸업했습니다!)" : ""}</div>
               <p class="text-slate-200">💡 <strong>해설:</strong> ${exp}</p>
             </div>`
          : `<div class="p-4 rounded-xl bg-rose-950/70 border border-rose-500/70 text-xs space-y-1">
               <div class="font-bold text-sm text-rose-300">🔴 오답입니다! (오답노트에 자동 등록되었습니다 — 아래 연계 이론과 확인 문제를 풀어보세요)</div>
               <p class="text-slate-200">💡 <strong>해설:</strong> ${exp}</p>
             </div>`;
        if (!th) return banner;

        const optsHtml = th.quiz.opts.map((o, i) => `
          <button data-th="${th.id}" data-idx="${i}" data-uid="${uid}"
            class="mini-q-btn w-full text-left px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 flex items-center justify-between">
            <span>${i + 1}. ${o}</span><span class="m-icon"></span>
          </button>`).join("");

        return `
          ${banner}
          <div class="p-5 rounded-2xl bg-indigo-950/40 border border-indigo-700/50 space-y-3">
            <div class="flex items-center justify-between">
              <span class="px-2.5 py-0.5 rounded bg-indigo-600 text-white text-xs font-bold">🔗 연계 핵심 이론 노트</span>
              <span class="text-xs font-mono text-indigo-300">${th.categoryName}</span>
            </div>
            <h4 class="text-sm font-bold text-white">${th.title}</h4>
            <p class="text-xs text-slate-300 leading-relaxed">${th.summary}</p>
            <ul class="text-xs text-slate-300 space-y-1 list-disc list-inside bg-slate-950/80 p-3 rounded-xl border border-slate-800">
              ${th.points.map(p => `<li>${p}</li>`).join("")}
            </ul>
            <div class="p-3.5 rounded-xl bg-slate-900 border border-slate-700 space-y-2">
              <p class="text-xs font-bold text-cyan-300">⚡ ${th.quiz.q}</p>
              <div class="space-y-1.5" id="${uid}_opts">${optsHtml}</div>
              <p id="${uid}_msg" class="hidden text-xs pt-1"></p>
            </div>
          </div>`;
      }

      bindMiniQuiz(container) {
        container.querySelectorAll(".mini-q-btn").forEach(btn => {
          btn.onclick = () => {
            const thId = btn.getAttribute("data-th");
            const idx = Number(btn.getAttribute("data-idx"));
            const uid = btn.getAttribute("data-uid");
            const th = DB.theories[thId];
            const isOk = idx === th.quiz.ans;
            this.recordTheoryQuiz(thId, isOk, th.title);

            const wrap = document.getElementById(`${uid}_opts`);
            wrap.querySelectorAll(".mini-q-btn").forEach((b, i) => {
              b.classList.remove("bg-emerald-950", "border-emerald-500", "bg-rose-950", "border-rose-500");
              if (i === th.quiz.ans) { b.classList.add("bg-emerald-950", "border-emerald-500"); b.querySelector(".m-icon").textContent = "🟢"; }
              else if (i === idx && !isOk) { b.classList.add("bg-rose-950", "border-rose-500"); b.querySelector(".m-icon").textContent = "🔴"; }
            });
            const msg = document.getElementById(`${uid}_msg`);
            msg.classList.remove("hidden");
            msg.className = isOk ? "text-xs pt-1 text-emerald-300 font-bold" : "text-xs pt-1 text-rose-300 font-bold";
            msg.textContent = isOk ? `✅ 정답! ${th.quiz.exp} (이론 정답률에 반영됨)` : `❌ 오답! ${th.quiz.exp}`;
            this.updateAnalyticsUI();
          };
        });
      }

      updateAnalyticsUI() {
        const thList = Object.values(DB.theories);
        let thSolved = 0, thOk = 0;
        thList.forEach(t => {
          const r = this.state.theories[t.id];
          if (r?.solved) { thSolved += 1; if (r.isOk) thOk += 1; }
        });
        const thAcc = thSolved > 0 ? Math.round((thOk / thSolved) * 100) : null;

        let wSolved = 0, wOk = 0;
        DB.written.forEach(q => {
          const st = this.state.questions[q.id];
          if (st?.solved > 0) { wSolved += 1; if (st.lastOk) wOk += 1; }
        });
        const wAcc = wSolved > 0 ? Math.round((wOk / wSolved) * 100) : null;

        let pSolved = 0, pOk = 0;
        DB.practical.forEach(q => {
          const st = this.state.questions[q.id];
          if (st?.solved > 0) { pSolved += 1; if (st.lastOk) pOk += 1; }
        });
        const pAcc = pSolved > 0 ? Math.round((pOk / pSolved) * 100) : null;

        const totalSolved = thSolved + wSolved + pSolved;
        const totalOk = thOk + wOk + pOk;
        const totalAcc = totalSolved > 0 ? Math.round((totalOk / totalSolved) * 100) : 0;

        let activeWrong = 0, gradCount = 0;
        [...DB.written, ...DB.practical].forEach(q => {
          const st = this.state.questions[q.id];
          if (!st) return;
          if (st.mastered) gradCount += 1;
          else if (st.wrong > 0 || st.bookmarked) activeWrong += 1;
        });

        // 상단 및 KPI 업데이트
        document.getElementById("topAccuracy").textContent = `${totalAcc}%`;
        document.getElementById("topWrongBadge").textContent = activeWrong;
        document.getElementById("navWrongCount").textContent = activeWrong;

        document.getElementById("kpiAccuracy").textContent = `${totalAcc}%`;
        document.getElementById("kpiAccuracyDesc").textContent = totalSolved > 0 ? `총 ${totalSolved}문항 중 ${totalOk}문항 정답` : "아직 풀이 기록이 없습니다";
        document.getElementById("kpiSolvedCount").textContent = this.state.logs.length;
        document.getElementById("kpiWrongCount").textContent = activeWrong;
        document.getElementById("kpiGraduatedDesc").textContent = `2회 연속 정답 졸업: ${gradCount}건`;
        document.getElementById("kpiTheoryDesc").textContent = `이론 확인문제 마스터: ${thOk} / ${thList.length}`;
        document.getElementById("kpiPassStatus").textContent =
          totalSolved === 0 ? "학습 대기중" : (totalAcc >= 60 ? "✅ 합격 안정권 (60점+)" : "⚠️ 보완 필요 (60점 미만)");

        // OVERVIEW 대분류(이론/필기/실기) 바 렌더링
        const mainBars = [
          { label: "이론 (Theory)", acc: thAcc, detail: `${thOk}/${thList.length} 마스터` },
          { label: "필기 (Written CBT)", acc: wAcc, detail: `${wOk}/${DB.written.length} 정답` },
          { label: "실기 (Practical CLI/작업)", acc: pAcc, detail: `${pOk}/${DB.practical.length} 정답` }
        ];
        document.getElementById("overviewMainBars").innerHTML = mainBars.map(b => `
          <div class="space-y-1.5">
            <div class="flex justify-between text-xs">
              <span class="font-bold text-slate-200">${b.label}</span>
              <span class="font-mono font-bold ${b.acc === null ? "text-slate-500" : (b.acc >= 60 ? "text-emerald-400" : "text-rose-400")}">
                ${b.acc === null ? "- (미풀이)" : `${b.acc}% (${b.detail})`}
              </span>
            </div>
            <div class="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300 ${b.acc >= 60 ? "bg-indigo-500" : "bg-rose-500"}" style="width: ${b.acc || 0}%"></div>
            </div>
          </div>`).join("");

        // 세부 과목별 바
        const subCats = [
          { name: "1과목: 네트워크 일반", list: DB.written.filter(q => q.sub === "S1_NET") },
          { name: "2과목: TCP/IP", list: DB.written.filter(q => q.sub === "S2_TCPIP") },
          { name: "3과목: NOS (Linux/Win)", list: DB.written.filter(q => q.sub === "S3_NOS") },
          { name: "4과목: 네트워크 운용기기", list: DB.written.filter(q => q.sub === "S4_HW") },
          { name: "실기: Router CLI & 케이블/서버", list: DB.practical }
        ];
        document.getElementById("overviewSubBars").innerHTML = subCats.map(c => {
          let s = 0, ok = 0;
          c.list.forEach(q => {
            const st = this.state.questions[q.id];
            if (st?.solved > 0) { s += 1; if (st.lastOk) ok += 1; }
          });
          const pct = s > 0 ? Math.round((ok / s) * 100) : 0;
          return `
            <div class="space-y-1">
              <div class="flex justify-between">
                <span class="text-slate-300">${c.name}</span>
                <span class="font-mono text-slate-400">${pct}% (${ok}/${c.list.length})</span>
              </div>
              <div class="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div class="h-full bg-emerald-500" style="width: ${pct}%"></div>
              </div>
            </div>`;
        }).join("");
      }

      renderTheoryView() {
        const list = Object.values(DB.theories).filter(t => this.tFilter === "ALL" ? true : t.category === this.tFilter);
        const box = document.getElementById("theoryListContainer");
        box.innerHTML = list.map(th => {
          const rec = this.state.theories[th.id];
          const uid = `TH_VIEW_${th.id}`;
          return `
            <div class="p-5 rounded-2xl bg-slate-900 border ${rec?.isOk ? "border-emerald-600/50" : "border-slate-800"} flex flex-col justify-between space-y-4">
              <div class="space-y-2.5">
                <div class="flex items-center justify-between">
                  <span class="px-2.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700/50 text-xs font-bold">${th.categoryName}</span>
                  <span class="text-xs font-bold ${rec?.isOk ? "text-emerald-400" : "text-amber-300"}">${rec?.isOk ? "✅ 마스터 완료" : "📝 확인 문제 대기"}</span>
                </div>
                <h4 class="text-base font-bold text-white">${th.title}</h4>
                <p class="text-xs text-slate-300 leading-relaxed">${th.summary}</p>
                <ul class="text-xs text-slate-300 space-y-1 list-disc list-inside bg-slate-950 p-3 rounded-xl border border-slate-800">
                  ${th.points.map(p => `<li>${p}</li>`).join("")}
                </ul>
              </div>
              <div class="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <p class="text-xs font-bold text-cyan-300">⚡ ${th.quiz.q}</p>
                <div class="space-y-1.5" id="${uid}_opts">
                  ${th.quiz.opts.map((o, i) => `
                    <button data-th="${th.id}" data-idx="${i}" data-uid="${uid}"
                      class="mini-q-btn w-full text-left px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 flex items-center justify-between">
                      <span>${i + 1}. ${o}</span><span class="m-icon"></span>
                    </button>`).join("")}
                </div>
                <p id="${uid}_msg" class="hidden text-xs pt-1"></p>
              </div>
            </div>`;
        }).join("");
        this.bindMiniQuiz(box);
      }

      getWrittenList() {
        const l = DB.written.filter(q => this.wSub === "ALL" ? true : q.sub === this.wSub);
        return l.length > 0 ? l : DB.written;
      }

      renderWrittenView() {
        const list = this.getWrittenList();
        if (this.wIdx >= list.length) this.wIdx = 0;
        const q = list[this.wIdx];
        const st = this.getQStat(q.id);

        document.getElementById("writtenCounter").textContent = `문항 ${this.wIdx + 1} / ${list.length}`;
        document.getElementById("writtenCatBadge").textContent = q.subName;
        document.getElementById("writtenStatBadge").textContent = st.solved > 0 ? `풀이 ${st.solved}회 · 오답 ${st.wrong}회 · 연속정답 ${st.streak}회` : "첫 풀이";
        document.getElementById("btnWrittenBookmark").textContent = st.bookmarked ? "🌟 헷갈림 등록됨" : "⭐ 헷갈림 체크";
        document.getElementById("writtenQText").textContent = `Q. ${q.q}`;

        const codeBox = document.getElementById("writtenCodeBox");
        if (q.code) { codeBox.textContent = q.code; codeBox.classList.remove("hidden"); } else { codeBox.classList.add("hidden"); }

        const fb = document.getElementById("writtenFeedbackBox");
        fb.classList.add("hidden");

        const choicesBox = document.getElementById("writtenChoicesBox");
        choicesBox.innerHTML = "";
        const nums = ["①", "②", "③", "④"];
        q.choices.forEach((c, idx) => {
          const btn = document.createElement("button");
          btn.className = "w-full px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left flex items-center justify-between text-sm font-medium text-slate-100";
          btn.innerHTML = `<span><strong class="mr-2 text-indigo-400">${nums[idx]}</strong>${c}</span><span class="c-icon"></span>`;
          btn.onclick = () => {
            const isOk = idx === q.ans;
            const { grad } = this.recordAttempt(q.id, isOk, "필기", q.q);
            choicesBox.querySelectorAll("button").forEach((b, i) => {
              b.classList.remove("bg-slate-800", "border-slate-700", "bg-emerald-950/80", "border-emerald-500", "bg-rose-950/80", "border-rose-500");
              if (i === q.ans) { b.classList.add("bg-emerald-950/80", "border-emerald-500"); b.querySelector(".c-icon").textContent = "🟢"; }
              else if (i === idx && !isOk) { b.classList.add("bg-rose-950/80", "border-rose-500"); b.querySelector(".c-icon").textContent = "🔴"; }
            });
            fb.innerHTML = this.buildLinkedTheoryHtml(q.theoryId, isOk, q.exp, grad, `W_${q.id}`);
            fb.classList.remove("hidden");
            this.bindMiniQuiz(fb);
            this.updateAnalyticsUI();
          };
          choicesBox.appendChild(btn);
        });
      }

      getPracticalList() {
        const l = DB.practical.filter(q => this.pSub === "ALL" ? true : q.pType === this.pSub);
        return l.length > 0 ? l : DB.practical;
      }

      renderPracticalView() {
        const list = this.getPracticalList();
        if (this.pIdx >= list.length) this.pIdx = 0;
        const q = list[this.pIdx];
        const st = this.getQStat(q.id);

        document.getElementById("practicalCounter").textContent = `실습 ${this.pIdx + 1} / ${list.length}`;
        document.getElementById("practicalCatBadge").textContent = q.pTypeName;
        document.getElementById("practicalStatBadge").textContent = st.solved > 0 ? `풀이 ${st.solved}회 · 오답 ${st.wrong}회 · 연속정답 ${st.streak}회` : "첫 실습";
        document.getElementById("btnPracticalBookmark").textContent = st.bookmarked ? "🌟 헷갈림 등록됨" : "⭐ 헷갈림 체크";
        document.getElementById("practicalQText").textContent = q.q;
        document.getElementById("practicalScenario").textContent = q.scenario;

        const cliArea = document.getElementById("practicalCliArea");
        const choiceArea = document.getElementById("practicalChoiceArea");
        const fb = document.getElementById("practicalFeedbackBox");
        fb.classList.add("hidden");

        if (q.pType === "CLI_ROUTER" || q.pType === "CLI_LINUX") {
          cliArea.classList.remove("hidden");
          choiceArea.classList.add("hidden");
          document.getElementById("cliPrompt").textContent = q.prompt;
          const inp = document.getElementById("cliInput");
          inp.value = "";
          const hintBox = document.getElementById("cliHintBox");
          hintBox.classList.add("hidden");
          hintBox.textContent = `💡 힌트: ${q.hint}`;

          const runEval = () => {
            const val = inp.value.trim().toLowerCase().replace(/\s+/g, " ");
            if (!val) return;
            const isOk = q.cmds.some(c => c.toLowerCase() === val);
            const { grad } = this.recordAttempt(q.id, isOk, "실기CLI", q.q);
            fb.innerHTML = this.buildLinkedTheoryHtml(q.theoryId, isOk, `${q.exp} (허용 명령어: ${q.cmds.join(" / ")})`, grad, `P_${q.id}`);
            fb.classList.remove("hidden");
            this.bindMiniQuiz(fb);
            this.updateAnalyticsUI();
          };
          document.getElementById("btnEvalCli").onclick = runEval;
          inp.onkeydown = (e) => { if (e.key === "Enter") runEval(); };
          document.getElementById("btnHintCli").onclick = () => hintBox.classList.toggle("hidden");
        } else {
          cliArea.classList.add("hidden");
          choiceArea.classList.remove("hidden");
          choiceArea.innerHTML = "";
          const nums = ["①", "②", "③", "④"];
          q.choices.forEach((c, idx) => {
            const btn = document.createElement("button");
            btn.className = "w-full px-4 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left flex items-center justify-between text-sm font-medium text-slate-100";
            btn.innerHTML = `<span><strong class="mr-2 text-cyan-400">${nums[idx]}</strong>${c}</span><span class="c-icon"></span>`;
            btn.onclick = () => {
              const isOk = idx === q.ans;
              const { grad } = this.recordAttempt(q.id, isOk, "실기작업", q.q);
              choiceArea.querySelectorAll("button").forEach((b, i) => {
                b.classList.remove("bg-slate-800", "border-slate-700", "bg-emerald-950/80", "border-emerald-500", "bg-rose-950/80", "border-rose-500");
                if (i === q.ans) { b.classList.add("bg-emerald-950/80", "border-emerald-500"); b.querySelector(".c-icon").textContent = "🟢"; }
                else if (i === idx && !isOk) { b.classList.add("bg-rose-950/80", "border-rose-500"); b.querySelector(".c-icon").textContent = "🔴"; }
              });
              fb.innerHTML = this.buildLinkedTheoryHtml(q.theoryId, isOk, q.exp, grad, `P_${q.id}`);
              fb.classList.remove("hidden");
              this.bindMiniQuiz(fb);
              this.updateAnalyticsUI();
            };
            choiceArea.appendChild(btn);
          });
        }
      }

      renderWrongNoteView() {
        const all = [
          ...DB.written.map(q => ({ ...q, mode: "written", badge: q.subName })),
          ...DB.practical.map(q => ({ ...q, mode: "practical", badge: q.pTypeName }))
        ];
        const filtered = all.filter(q => {
          const st = this.state.questions[q.id];
          if (!st) return false;
          return this.wMode === "MASTERED" ? st.mastered : (!st.mastered && (st.wrong > 0 || st.bookmarked));
        });
        const box = document.getElementById("wrongListBox");
        if (filtered.length === 0) {
          box.innerHTML = `<div class="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-center text-sm text-slate-400">등록된 오답 문항이 없습니다. 문제를 풀면서 틀리거나 헷갈림 체크를 해보세요!</div>`;
          return;
        }
        box.innerHTML = filtered.map(q => {
          const st = this.getQStat(q.id);
          return `
            <div class="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div class="flex items-center justify-between">
                <span class="px-2.5 py-0.5 rounded bg-rose-950 text-rose-300 text-xs font-bold">${q.badge} · 오답 ${st.wrong}회 (연속정답 ${st.streak}/2)</span>
                <button data-id="${q.id}" data-mode="${q.mode}" class="retry-btn px-3.5 py-1.5 rounded-xl bg-indigo-600 text-xs font-bold text-white">다시 풀기 →</button>
              </div>
              <p class="text-sm font-bold text-white">${q.q}</p>
              <p class="text-xs text-emerald-300">💡 핵심 해설: ${q.exp}</p>
            </div>`;
        }).join("");
        box.querySelectorAll(".retry-btn").forEach(btn => {
          btn.onclick = () => {
            const id = btn.getAttribute("data-id");
            const mode = btn.getAttribute("data-mode");
            if (mode === "written") { this.wSub = "ALL"; this.wIdx = DB.written.findIndex(x => x.id === id); this.switchTab("written"); }
            else { this.pSub = "ALL"; this.pIdx = DB.practical.findIndex(x => x.id === id); this.switchTab("practical"); }
          };
        });
      }

      renderRecordsView() {
        const box = document.getElementById("recordsTimelineBox");
        if (this.state.logs.length === 0) {
          box.innerHTML = `<div class="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-center text-sm text-slate-400">아직 기록된 로컬 학습 이력이 없습니다.</div>`;
          return;
        }
        box.innerHTML = this.state.logs.map(l => `
          <div class="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2.5">
              <span>${l.isOk ? "🟢" : "🔴"}</span>
              <span class="px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-bold">${l.label}</span>
              <span class="text-slate-200 font-medium">${l.title}</span>
              ${l.grad ? `<span class="px-2 py-0.5 rounded bg-emerald-900 text-emerald-300 font-bold">🎓 오답졸업</span>` : ""}
            </div>
            <span class="font-mono text-slate-400">${l.time}</span>
          </div>`).join("");
      }

      refreshAll() {
        this.updateAnalyticsUI();
        this.renderTheoryView();
        this.renderWrittenView();
        this.renderPracticalView();
        this.renderWrongNoteView();
        this.renderRecordsView();
      }

      bindEvents() {
        document.querySelectorAll(".main-tab-btn").forEach(btn => {
          btn.onclick = () => this.switchTab(btn.getAttribute("data-tab"));
        });
        document.getElementById("btnRunSubnetCalc").onclick = () => this.runSubnetCalculator();

        document.querySelectorAll(".tfilter-btn").forEach(btn => {
          btn.onclick = () => {
            this.tFilter = btn.getAttribute("data-tfilter");
            this.renderTheoryView();
          };
        });
        document.querySelectorAll(".wsub-btn").forEach(btn => {
          btn.onclick = () => {
            this.wSub = btn.getAttribute("data-wsub");
            this.wIdx = 0;
            this.renderWrittenView();
          };
        });
        document.getElementById("btnWrittenPrev").onclick = () => { if (this.wIdx > 0) { this.wIdx -= 1; this.renderWrittenView(); } };
        document.getElementById("btnWrittenNext").onclick = () => {
          const l = this.getWrittenList();
          if (this.wIdx < l.length - 1) { this.wIdx += 1; this.renderWrittenView(); } else { this.switchTab("dashboard"); }
        };
        document.getElementById("btnWrittenBookmark").onclick = () => {
          const q = this.getWrittenList()[this.wIdx];
          const st = this.getQStat(q.id);
          st.bookmarked = !st.bookmarked;
          this.saveState();
          this.renderWrittenView();
          this.updateAnalyticsUI();
        };

        document.querySelectorAll(".psub-btn").forEach(btn => {
          btn.onclick = () => {
            this.pSub = btn.getAttribute("data-psub");
            this.pIdx = 0;
            this.renderPracticalView();
          };
        });
        document.getElementById("btnPracticalPrev").onclick = () => { if (this.pIdx > 0) { this.pIdx -= 1; this.renderPracticalView(); } };
        document.getElementById("btnPracticalNext").onclick = () => {
          const l = this.getPracticalList();
          if (this.pIdx < l.length - 1) { this.pIdx += 1; this.renderPracticalView(); } else { this.switchTab("dashboard"); }
        };
        document.getElementById("btnPracticalBookmark").onclick = () => {
          const q = this.getPracticalList()[this.pIdx];
          const st = this.getQStat(q.id);
          st.bookmarked = !st.bookmarked;
          this.saveState();
          this.renderPracticalView();
          this.updateAnalyticsUI();
        };

        document.querySelectorAll(".wmode-btn").forEach(btn => {
          btn.onclick = () => {
            this.wMode = btn.getAttribute("data-wmode");
            this.renderWrongNoteView();
          };
        });

        document.getElementById("btnExportJson").onclick = () => {
          navigator.clipboard?.writeText(JSON.stringify(this.state, null, 2));
          alert("학습 레코드 JSON이 클립보드에 복사되었습니다!");
        };
        document.getElementById("btnImportJson").onclick = () => {
          const raw = prompt("복원할 JSON 문자열을 붙여넣으세요:");
          if (raw) {
            try { this.state = JSON.parse(raw); this.saveState(); this.refreshAll(); alert("복원 완료!"); } catch (_) {}
          }
        };
        document.getElementById("btnResetAll").onclick = () => {
          if (confirm("모든 학습 기록을 초기화할까요?")) {
            this.state = this.defaultState();
            this.saveState();
            this.refreshAll();
          }
        };
      }
    }

    export const app = new AppController();
window.app = app;
    window.addEventListener("DOMContentLoaded", () => app.init());
