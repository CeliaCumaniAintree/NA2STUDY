import { DB } from '../src/data/db.js';

let errors = 0;
const theoryIds = new Set(Object.keys(DB.theories));

for (const q of DB.written) {
  if (!theoryIds.has(q.theoryId)) {
    console.error(`[ERROR] Written question ${q.id} references missing theoryId: ${q.theoryId}`);
    errors++;
  }
}

for (const q of DB.practical) {
  if (!theoryIds.has(q.theoryId)) {
    console.error(`[ERROR] Practical question ${q.id} references missing theoryId: ${q.theoryId}`);
    errors++;
  }
}

console.log(`✅ Verified ${theoryIds.size} theories, ${DB.written.length} written questions, and ${DB.practical.length} practical labs.`);
if (errors > 0) process.exit(1);
