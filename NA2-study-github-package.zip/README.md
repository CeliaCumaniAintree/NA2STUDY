# 🌐 NA2-study (네트워크관리사 2급 통합 학습 대시보드)

> **네트워크관리사 2급 합격을 위한 올인원 학습 솔루션**  
> 이론 · 필기 4지선다 CBT · 실기 작업형/단답형(Router CLI & UTP 케이블링) · 스마트 오답노트 · 실시간 IP 서브넷 계산기 · 브라우저 로컬 학습 레코드 통합 애플리케이션

---

## ✨ 주요 기능 (Key Features)

1. **📊 통합 학습 대시보드 & 실시간 서브넷 계산기**
   - 전체 정답률, 오늘 푼 문제 수, 오답노트 복습 대상, 이론 마스터 및 60점 합격 안정권 판독 KPI 제공
   - 영역별(이론 / 필기 / 실기) 및 세부 과목별(1~4과목, 실기) 실시간 정답률 시각화
   - **실시간 IPv4 서브넷 계산기**: IP와 CIDR(`/24`~`/30`) 입력 시 서브넷 마스크, 네트워크 ID, 브로드캐스트 주소, 가용 호스트 범위 즉시 도출 + 8비트 2진수 암산 토글기 탑재

2. **📖 과목별 핵심 이론 & 즉시 확인 퀴즈**
   - 1과목(네트워크 일반), 2과목(TCP/IP), 3과목(NOS), 4과목(네트워크 운용기기), 실기 핵심 이론 정리
   - 각 이론 카드 하단에 3지선다 확인 문제를 배치하여 개념 이해도를 즉시 점검하고 이론 정답률에 반영

3. **✍️ 필기 집중 학습 (4지선다 CBT)**
   - 전 과목 또는 과목별 필터링 풀이 및 `⭐ 헷갈림 체크` 북마크 지원
   - 문제 정·오답 판정 즉시 **핵심 해설 + 연계 이론 노트 + 미니 확인 문제**를 한 화면에서 연속 학습

4. **💻 실기 작업형 / 단답형 에뮬레이터**
   - **Cisco Router IOS CLI & Linux 단답형 터미널**: 실제 시험에서 허용되는 명령어 축약어(`no sh`, `copy r s`, `wr`, `netstat -an` 등) 완벽 채점 및 힌트 제공
   - **UTP 케이블링(T568A/B) & Windows Server 작업형**: 다이렉트/크로스 케이블 핀 배열 및 DNS 역방향 조회 영역(PTR) 실습

5. **🚨 스마트 오답 시스템 (2회 연속 정답 자동 졸업)**
   - 틀린 문제 및 `⭐ 헷갈림 체크` 문항 자동 수집
   - 오답 복습 시 **2회 연속 정답**을 달성하면 오답노트에서 자동 졸업(`🎓 졸업 완료`) 처리

6. **🗂️ 로컬 브라우저 레코드 (LocalStorage) & JSON 백업/복원**
   - 별도 서버 없이 브라우저 `localStorage`(`NA2_STUDY_MASTER_V2`)에 모든 풀이 이력과 타임라인 영구 보존
   - 클립보드 기반 JSON 백업 복사 및 복원 기능 지원

---

## 📁 저장소 폴더 구조 (Repository Structure)

```text
NA2-study/
├── .github/workflows/
│   └── deploy.yml                  # GitHub Pages 자동 배포 워크플로우
├── content-review/
│   └── curriculum-checklist.md     # 필기 4과목 및 실기 출제기준 검수 리스트
├── docs/
│   └── deployment-record.md        # GitHub Pages 배포 및 실습 검증 기록
├── public/
│   └── favicon.svg                 # N2 로고 아이콘
├── scripts/
│   └── verify-content.js           # 문제은행(DB) 무결성 및 연계 이론 ID 검증 스크립트
├── src/
│   ├── data/
│   │   └── db.js                   # 이론(theories), 필기(written), 실기(practical) 데이터셋
│   ├── styles/
│   │   └── main.css                # 커스텀 그라디언트 및 카드 호버 스타일
│   └── main.js                     # AppController 상태 관리, 서브넷 계산기, UI 렌더링 로직
├── tests/
│   └── app.test.js                 # 서브넷 계산 및 오답 졸업 로직 단위 테스트
├── .gitattributes
├── .gitignore
├── DESIGN.md                       # UI/UX 아키텍처 및 데이터 흐름 설계 문서
├── README.md                       # 프로젝트 소개 및 실행 가이드
├── index.html                      # 메인 엔트리 HTML (단독 실행 및 Vite 빌드 호환)
├── package-lock.json
├── package.json
└── vite.config.js
```

---

## 🚀 시작하기 (Getting Started)

### 1) 브라우저 단독 실행 (Zero-Build)
`index.html` 파일은 단독 실행이 가능하도록 구성되어 있어, 더블클릭하거나 정적 웹 서버로 즉시 실행할 수 있습니다.

### 2) 로컬 개발 서버 실행 (Vite)
```bash
npm install
npm run dev
```

### 3) 콘텐츠 검증 및 프로덕션 빌드
```bash
npm run verify
npm test
npm run build
```

---

## 🌐 GitHub Pages 배포 안내
`main` 브랜치에 푸시하면 `.github/workflows/deploy.yml` 액션이 자동으로 실행되어 GitHub Pages로 배포됩니다.
- 저장소 **Settings → Pages → Build and deployment → Source**를 **GitHub Actions**로 설정하세요.
