# 네트워크관리사 2급 출제기준 및 콘텐츠 검수표

| 분류 | 코드 | 핵심 주제 | 연계 문항 ID | 검수 상태 |
| :--- | :--- | :--- | :--- | :--- |
| 1과목: 네트워크 일반 | `TH_OSI7` | OSI 7계층 구조와 계층별 PDU (Bit/Frame/Packet/Segment) | `WQ_01` | ✅ 완료 |
| 1과목: 네트워크 일반 | `TH_CSMA` | 매체 접근 제어: 유선 CSMA/CD vs 무선 CSMA/CA | `WQ_02` | ✅ 완료 |
| 2과목: TCP/IP | `TH_SUBNET` | IPv4 C클래스 서브넷팅 및 CIDR 가용 호스트 계산 | `WQ_03` | ✅ 완료 |
| 2과목: TCP/IP | `TH_ARP` | ARP / RARP 주소 변환 프로토콜 및 필수 포트 번호 | `WQ_04`, `PQ_05` | ✅ 완료 |
| 3과목: NOS | `TH_LINUX` | Linux `chmod` 8진수 권한 및 `/etc/resolv.conf` 설정 | `WQ_05`, `WQ_06`, `PQ_03` | ✅ 완료 |
| 4과목: 네트워크 운용기기 | `TH_DEVICE` | 라우터(3계층), 스위치(2계층), VLAN 브로드캐스트 분할 | `WQ_07`, `WQ_08` | ✅ 완료 |
| 실기: 케이블링 & 서버 | `TH_CABLE` | UTP 케이블 T568A/B 선 배열 및 다이렉트/크로스 구분 | `PQ_04` | ✅ 완료 |
| 실기: Router CLI | `TH_ROUTER` | Cisco IOS 인터페이스 활성화(`no sh`) 및 NVRAM 저장(`copy r s`) | `PQ_01`, `PQ_02` | ✅ 완료 |
