# DESIGN.md — NA2 Study Master 아키텍처 및 UI 설계 문서

## 1. 설계 목표 (Design Goals)
- **통학 20분 1-DAY 루프**: 상단 20분 타이머와 함께 이론 → 필기 → 실기 → 오답노트 복습을 한 화면 전환으로 끊김 없이 수행.
- **문제-이론 즉각 피드백 루프**: 필기/실기 문제를 풀면 정·오답 해설뿐 아니라 해당 문항과 연결된 `theoryId` 기반의 **핵심 이론 요약 + 미니 확인 퀴즈**를 즉시 노출.
- **2회 연속 정답 졸업 알고리즘**: 오답 또는 헷갈림 북마크 문항이더라도 이후 풀이에서 `streak >= 2` 달성 시 `mastered = true`로 전환하여 성취감 부여.

## 2. 컬러 시스템 & 타이포그래피
- **배경 테마**: 다크 슬레이트(`#020617` / `bg-slate-950`) 및 카드 표면(`#0f172a` / `bg-slate-900`)으로 눈의 피로 최소화.
- **포인트 컬러**:
  - 필기 / 메인 브랜드: Indigo (`#4f46e5`)
  - 실기 CLI / 서브넷 툴: Cyan (`#0891b2`)
  - 정답 / 합격 안정권 / 졸업: Emerald (`#10b981`)
  - 오답 / 복습 대상: Rose (`#f43f5e`)
- **폰트**: `Pretendard` (본문 UI) + `Monospace` (라우터 CLI 프롬프트, IP 주소, 타이머, 점수 지표)

## 3. 데이터 스키마 (`LocalStorage: NA2_STUDY_MASTER_V2`)
```json
{
  "theories": {
    "TH_OSI7": { "solved": true, "isOk": true }
  },
  "questions": {
    "WQ_01": {
      "solved": 2,
      "correct": 2,
      "wrong": 1,
      "streak": 2,
      "bookmarked": false,
      "mastered": true,
      "lastOk": true
    }
  },
  "logs": [
    {
      "time": "15:00:00",
      "label": "필기",
      "id": "WQ_01",
      "title": "OSI 7계층 중 프레임(Frame) 단위의 데이터 전송...",
      "isOk": true,
      "grad": true
    }
  ]
}
```
