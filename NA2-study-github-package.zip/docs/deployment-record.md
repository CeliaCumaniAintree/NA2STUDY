# Deployment & Practical Lab Verification Record

## 1. 배포 환경 요약
- **Target URL**: `https://sumilee-phd.github.io/NA2-study/`
- **Build System**: Vite + GitHub Actions (`actions/deploy-pages@v4`)
- **Standalone Compatibility**: `index.html` 자체 실행 및 모듈 번들링 호환 완료

## 2. 기능 검증 체크리스트
- [x] 상단 20분 통학 타이머 카운트다운 정상 동작
- [x] 실시간 IP 서브넷 계산기 (`/24` ~ `/30`) 네트워크 ID / 브로드캐스트 / 가용 호스트 계산 검증
- [x] 8비트 2진수 합산 토글 바 (`128, 64, 32, 16, 8, 4, 2, 1`) 합계 연동 확인
- [x] 필기 4과목 및 실기 CLI 축약 명령어(`no sh`, `copy r s`, `wr`, `netstat -an`) 채점 확인
- [x] 오답노트 2회 연속 정답 시 자동 졸업(`mastered: true`) 전환 확인
