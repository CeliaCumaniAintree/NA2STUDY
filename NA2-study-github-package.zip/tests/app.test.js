import test from 'node:test';
import assert from 'node:assert/strict';
import { DB } from '../src/data/db.js';

test('DB has complete theories, written questions, and practical tasks', () => {
  assert.equal(Object.keys(DB.theories).length, 8);
  assert.equal(DB.written.length, 8);
  assert.equal(DB.practical.length, 5);
});

test('Subnet /26 calculation yields 62 usable hosts and .192 mask', () => {
  const cidr = 26;
  const hostBits = 32 - cidr;
  const blockSize = Math.pow(2, hostBits);
  const maskOctet = 256 - blockSize;
  const usableHosts = blockSize - 2;
  assert.equal(maskOctet, 192);
  assert.equal(usableHosts, 62);
});
